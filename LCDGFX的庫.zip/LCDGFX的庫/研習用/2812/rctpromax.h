#pragma once
#include <stdint.h>//提供固定寬度的整數型別

template <typename T>
inline void swap(T &a, T &b) {
    T t = a; a = b; b = t;
}

inline void drawCircleFilledWithBorder(DisplayST7735_128x160x16_SPI& display, int x0, int y0, int r,
                                       uint16_t fillColor, uint16_t borderColor){//實心圓
    display.setColor(fillColor);
    for (int y = -r + 1; y < r; y++) {
        for (int x = -r + 1; x < r; x++) {
            if (x * x + y * y <= r*r) {
                display.putPixel(x0 + x, y0 + y);
            }
        }
    }
    display.setColor(borderColor);
    display.drawCircle(x0, y0, r);
}

inline void drawTriangle(DisplayST7735_128x160x16_SPI& display,
    int x0, int y0, int x1, int y1, int x2, int y2){//空心三角形
    display.drawLine(x0, y0, x1, y1);
    display.drawLine(x1, y1, x2, y2);
    display.drawLine(x2, y2, x0, y0);
}

inline void fillTriangle(DisplayST7735_128x160x16_SPI& display,
                         int x0, int y0, int x1, int y1, int x2, int y2)
{
    if (y0 > y1) { swap(y0, y1); swap(x0, x1); }
    if (y1 > y2) { swap(y1, y2); swap(x1, x2); }
    if (y0 > y1) { swap(y0, y1); swap(x0, x1); }

    auto edge = [](int x0, int y0, int x1, int y1, int y) -> int {
        if (y1 == y0) return x0;
        return x0 + (x1 - x0) * (y - y0) / (y1 - y0);
    };

    for (int y = y0; y <= y2; y++) {
        int xa, xb;
        if (y < y1) {
            xa = edge(x0, y0, x1, y1, y);
            xb = edge(x0, y0, x2, y2, y);
        } else {
            xa = edge(x1, y1, x2, y2, y);
            xb = edge(x0, y0, x2, y2, y);
        }
        if (xa > xb) swap(xa, xb);
        display.drawHLine(xa, y, xb - xa + 1);
    }
}

inline void fillTriangleWithBorder(DisplayST7735_128x160x16_SPI& display,
    int x0, int y0, int x1, int y1, int x2, int y2,
    uint16_t fillColor, uint16_t borderColor){//實心三角形
    display.setColor(fillColor);
    fillTriangle(display, x0, y0, x1, y1, x2, y2);

    display.setColor(borderColor);
    drawTriangle(display, x0, y0, x1, y1, x2, y2);
}