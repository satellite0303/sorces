﻿using System;

namespace WindowsFormsApp1
{
    internal class ManagementObjectSearcher : IDisposable
    {
        private string v;

        public ManagementObjectSearcher(string v)
        {
            this.v = v;
        }
    }
}