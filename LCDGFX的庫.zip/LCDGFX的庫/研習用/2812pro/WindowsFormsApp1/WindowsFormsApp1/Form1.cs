﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.IO.Ports;
using System.Windows.Forms;
using System.Threading;
using Newtonsoft.Json.Linq;
using Microsoft.VisualBasic.PowerPacks;
using System.Management;
using System.Text.RegularExpressions;
using System.Drawing.Printing;
using System.Printing;
using System.Runtime.InteropServices;

namespace WindowsFormsApp1{
    public partial class Form1 : Form{
        int[] send = new int[8];//傳輸的資料 不要改 不然底下outport的設定也要改
        //[模式(3結束連線4全暗5全亮6暗特定的7亮特定的8寫密碼9讀密碼10顯示密碼)11按鈕1 12按鈕2 13要介面卡的燈 14關介面卡燈，放點亮哪個led或ws(1) 或 密碼(1~4)]
        int isConnect = 0;//是否有連線 1(連線)0(未連線)
        string shapenum;//勾選的led或ws
        string comportname;//要用的埠名
        int readtimeout = 150, writetimeout = 50;//讀取&寫入的限制時間
        SerialPort SerialPort1= new SerialPort();//一個可以存要怎麼使用埠的物件 
        static int[] rbuf = new int[10];//整理好後的資料
        static string indata = "";//讀取進來時的資料
        bool canchange = false;//是否在同步資料
        int[][] rainbow8 = new int[][] {
            new int[] {210, 0, 0},
            new int[] {210, 110, 0},
            new int[] {210, 210, 0},
            new int[] {0, 210, 0},
            new int[] {0, 0, 210},
            new int[] {210, 0, 210},
            new int[] {0, 210, 210},
            new int[] {210, 210, 210},
            new int[] {250, 190, 200},
        };

        void closed() {//按鈕關閉及一些東西關掉
            label2.Text = "Device Offline";
            label2.BackColor = Color.Red;
            CheckBox[] ledshape = {  checkBox8, checkBox7, checkBox6, checkBox5, checkBox4, checkBox3, checkBox2, checkBox1 };//一個拿來裝checkbox的物件的類別'
            for (int i = 0; i <= 7; i++) { ledshape[i].Checked = false; ledshape[i].Enabled = false; }
            Button[] buttons = {button2};//一個拿來裝button的物件的類別'
            for (int i = 0; i !=1; i++) { buttons[i].Enabled = false; }
            OvalShape[] ovals = {ovalShape9, ovalShape10, ovalShape11, ovalShape12, ovalShape13, ovalShape14, ovalShape15, ovalShape16 };
            for (int i = 0; i <= 7; i++) { ovals[i].FillStyle = FillStyle.Transparent; }//選擇空心樣式
            button1.Enabled = true;
            timer1.Enabled = false;
            isConnect = 0;
        }

        void closeform() {//結束連線
            try{
                send[0] = 3;
                ComPortSend();
                closed();
            }
            catch (Exception ex){
                if (SerialPort1.IsOpen) SerialPort1.Close();
                isConnect = 0; 
            }
        }

        void ComPortSend(){//送電腦資料
            string tx = "[" + send[0] + "," + send[1] + "," + send[2] + "," + send[3] + "," + send[4] + "," + send[5] + "," + send[6] + "," + send[7] + "]";
            label3.Text = tx;//除錯用
            try{
                if (SerialPort1.IsOpen && isConnect == 1) SerialPort1.WriteLine(tx);
                SerialPort1.BaseStream.Flush(); //清空輸出緩衝區，強制資料立刻送出，不等待。
                Thread.Sleep(30);// 等 Arduino 接收、處理一下 因為以前的串列傳輸較慢
                if (send[0] == 3) { SerialPort1.Close(); }
            }//writeline預設加上 \r\n Write沒有
            catch { int a; }// 還沒開port
        }

        void same() {//同步資料
            canchange = true;
            CheckBox[] ledshape = { checkBox8, checkBox7, checkBox6, checkBox5, checkBox4, checkBox3, checkBox2, checkBox1 };//一個拿來裝checkbox的物件的類別'
            OvalShape[] ovals = { ovalShape16, ovalShape15, ovalShape14, ovalShape13, ovalShape12, ovalShape11, ovalShape10, ovalShape9 };
            int[] ram = { rbuf[1] / 100, rbuf[1] / 10%10, rbuf[1] % 10, rbuf[2] / 100, rbuf[2] / 10%10, rbuf[2] % 10, rbuf[3] / 10, rbuf[3] % 10, };
            for (int i = 0; i != 8; i++){
                if (ram[i] != 9) {//沒有關掉的話才點
                    ledshape[i].Checked = true;
                    ovals[i].FillStyle = FillStyle.Solid;//選擇實心樣式
                    ovals[i].FillColor = Color.FromArgb(rainbow8[ram[i]][0], rainbow8[ram[i]][1], rainbow8[ram[i]][2]);
                }
            }
            canchange = false;
        }

        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e){//收到資料要幹啥
            SerialPort sp = (SerialPort)sender;//轉成埠名的格式看是哪個埠在用
            try{
                indata = sp.ReadLine();//讀取到Port進來的資料
                if (indata.StartsWith("[") && indata.EndsWith("]\r")){//檢查開頭結尾是否符合格式 底下就跟arduinou一樣的事情
                    JArray array = JArray.Parse(indata);
                    for (int i = 0; i < array.Count; i++) { rbuf[i] = (int)array[i]; }//.count會回傳有幾個元素 因為傳過來是串列格式所以可以直接用0.1.2....的方式讀取
                    if (rbuf[0] == 404) { this.Invoke(new Action(ComPortSend)); }//錯誤碼
                    if (rbuf[0] == 5) { this.Invoke(new Action(same)); }//錯誤碼
                }
            }
            catch (Exception ex) { int a; }
        }

        public Form1(){//產生form類別的基礎屬性
            InitializeComponent();//初始化
            closed();
        }
       
        private void Form1_FormClosing(object sender, FormClosingEventArgs e) {closeform(); }//右上角的x

        private void comboBox1_Click(object sender, EventArgs e){//(使用這個函式的人是誰，事件的附加參數)
            comboBox1.Items.Clear();
            string[] sps = SerialPort.GetPortNames();//取得目前能用的埠名成串列
            comboBox1.Items.AddRange(sps);
        }

        private void comboBox2_Click(object sender, EventArgs e){
            comboBox2.Items.Clear();
            string[] sps = { "red   0", "orange1", "yellow2", "green 3", "blue  4", "purple5", "cyan  6", "white 7", "pink  8" };
            comboBox2.Items.AddRange(sps);
        }

        private void button1_Click(object sender, EventArgs e){//藍牙手動連線按鈕
            comportname = comboBox1.Text;
            try{//抓錯 跟Py的try except一樣
                if (!SerialPort1.IsOpen && isConnect == 0){
                    SerialPort1 = new SerialPort(comportname, 115200, Parity.None, 8, StopBits.One);//設定要用哪個埠 (名稱，鮑率，要檢查傳述是否有誤(odd奇校 even偶校 none不用)，數據長度，結尾會有幾個停止符號(告訴傳完了))
                    SerialPort1.ReadTimeout = readtimeout; // 讀取時間若超過這個值 會彈錯誤訊息
                    SerialPort1.WriteTimeout = writetimeout; // 寫入時間若超過這個值 會彈錯誤訊息
                    SerialPort1.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);//設定 接收到資料時要幹嘛 +=時是接受到資料時  後面是要做啥new後面那串後長的是指定被觸發時要幹嘛
                    
                    SerialPort1.Open();
                    if (SerialPort1.IsOpen){//啟用 關閉 按鈕
                        label2.Text = "Device Online";
                        label2.BackColor = Color.Green;
                        CheckBox[] ledshape = { checkBox8, checkBox7, checkBox6, checkBox5, checkBox4, checkBox3, checkBox2, checkBox1 };//一個拿來裝checkbox的物件的類別'
                        for (int i = 0; i <= 7; i++) { ledshape[i].Enabled = true; }
                        Button[] buttons = {  button2};//一個拿來裝button的物件的類別'
                        for (int i = 0; i != 1; i++) { buttons[i].Enabled = true; }
                        button1.Enabled = false;
                        timer1.Enabled = true;
                        isConnect = 1; // 連線
                        send[0] = 4;
                        ComPortSend();
                    }
                }
            }
            catch (Exception ex){// Exception(任何錯誤) ex(錯誤訊息)
                if (SerialPort1.IsOpen) SerialPort1.Close();//把埠關掉 避免後續出事
                isConnect = 0;
                MessageBox.Show(ex.ToString());//顯示異常的詳細信息
            }
        }

        private void button2_Click(object sender, EventArgs e) { closeform(); }//藍芽關閉  

        private void button5_Click(object sender, EventArgs e){// 結束應用程式  
            closeform();
            this.Close();
        }
        
        private void ovalShape_Click(object sender, EventArgs e){//連動checkbox
            OvalShape ovals = (sender as OvalShape);
            string cbName = (sender as OvalShape).Tag.ToString();
            CheckBox checks = this.Controls.Find(cbName, true).FirstOrDefault() as CheckBox;// 透過 Controls 找回那個 CheckBox    .FirstOrDefault()--取第一個符合條件的元素

            if (ovals.FillStyle == FillStyle.Solid){checks.Checked=false;}
            else { checks.Checked = true; }
        }
        
        private void checkBox1_CheckedChanged(object sender, EventArgs e){
            if (canchange) return;
            OvalShape[] ovals = { ovalShape16, ovalShape15, ovalShape14, ovalShape13, ovalShape12, ovalShape11, ovalShape10, ovalShape9 };

            shapenum = (string)(sender as CheckBox).Tag;//把目前使用函式的物件轉成checkbox型態 取得現在被勾選的led值(用來點亮用的)
            int rams = int.Parse(shapenum);
            send[1] = rams;//專門數字字串轉成數字型態(非數字報錯)(TryParse非數字會回傳false null回0) Convert.ToInt32()(非數字回傳0 但字串會出錯)

            if (((sender as CheckBox).Checked)){//有被勾取且不是要全亮時而是單個才進
                char colors = comboBox2.Text[comboBox2.Text.Length - 1];//要用的顏色代號
                int ram = colors- '0';  // 把字元數字轉成 int ((int)會把char變成ascll碼)
                send[0] = 7;
                send[2] = ram;

                ovals[rams].FillStyle = FillStyle.Solid;//選擇實心樣式
                ovals[rams].FillColor =  Color.FromArgb(rainbow8[ram][0], rainbow8[ram][1], rainbow8[ram][2]);//led?漸層?漸層:一般色:黃色
            }
            else if(send[0] != 3){ //被取消勾選 而不是要結束連線
                send[0] = 7;
                send[2] = 9;
                ovals[rams].FillStyle = FillStyle.Transparent;//選擇空心
            }//因為結束連線時會把勾選盒清空為避免影響到輸出(這裡會有反應)所以if加入send[0] !=3  
            ComPortSend();
        }
     }
}