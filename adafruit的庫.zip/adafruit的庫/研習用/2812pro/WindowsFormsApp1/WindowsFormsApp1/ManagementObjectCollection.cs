﻿namespace WindowsFormsApp1
{
    internal class ManagementObjectCollection
    {
    }
}