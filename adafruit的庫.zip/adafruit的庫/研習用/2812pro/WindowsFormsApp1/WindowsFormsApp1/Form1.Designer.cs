﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.shapeContainer2 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.ovalShape9 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape10 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape11 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape12 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape13 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape14 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape15 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape16 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(26, 85);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(114, 24);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.Text = "連接埠名稱";
            this.comboBox1.Click += new System.EventHandler(this.comboBox1_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(198, 52);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 38);
            this.button1.TabIndex = 4;
            this.button1.Text = "OPEN";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button2.Location = new System.Drawing.Point(198, 96);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(87, 40);
            this.button2.TabIndex = 5;
            this.button2.Text = "CLOSE";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button5
            // 
            this.button5.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button5.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button5.Location = new System.Drawing.Point(185, 192);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(100, 50);
            this.button5.TabIndex = 12;
            this.button5.Text = "離開";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("新細明體", 12F);
            this.label9.Location = new System.Drawing.Point(24, 154);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 16);
            this.label9.TabIndex = 46;
            this.label9.Text = "Device Status";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Font = new System.Drawing.Font("新細明體", 18F);
            this.label2.Location = new System.Drawing.Point(141, 154);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 24);
            this.label2.TabIndex = 49;
            this.label2.Text = "Device Offline";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 18F);
            this.label3.Location = new System.Drawing.Point(329, 479);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 24);
            this.label3.TabIndex = 50;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.comboBox2);
            this.groupBox3.Controls.Add(this.checkBox1);
            this.groupBox3.Controls.Add(this.checkBox2);
            this.groupBox3.Controls.Add(this.checkBox3);
            this.groupBox3.Controls.Add(this.checkBox4);
            this.groupBox3.Controls.Add(this.checkBox5);
            this.groupBox3.Controls.Add(this.checkBox6);
            this.groupBox3.Controls.Add(this.checkBox7);
            this.groupBox3.Controls.Add(this.checkBox8);
            this.groupBox3.Controls.Add(this.shapeContainer2);
            this.groupBox3.Location = new System.Drawing.Point(325, 52);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(677, 190);
            this.groupBox3.TabIndex = 61;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "ws2812 Control";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("新細明體", 18F);
            this.checkBox1.Location = new System.Drawing.Point(595, 79);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(65, 28);
            this.checkBox1.TabIndex = 57;
            this.checkBox1.Tag = "7";
            this.checkBox1.Text = "ws0";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("新細明體", 18F);
            this.checkBox2.Location = new System.Drawing.Point(515, 79);
            this.checkBox2.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(65, 28);
            this.checkBox2.TabIndex = 56;
            this.checkBox2.Tag = "6";
            this.checkBox2.Text = "ws1";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("新細明體", 18F);
            this.checkBox3.Location = new System.Drawing.Point(434, 79);
            this.checkBox3.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(65, 28);
            this.checkBox3.TabIndex = 55;
            this.checkBox3.Tag = "5";
            this.checkBox3.Text = "ws2";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("新細明體", 18F);
            this.checkBox4.Location = new System.Drawing.Point(345, 79);
            this.checkBox4.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(65, 28);
            this.checkBox4.TabIndex = 54;
            this.checkBox4.Tag = "4";
            this.checkBox4.Text = "ws3";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Font = new System.Drawing.Font("新細明體", 18F);
            this.checkBox5.Location = new System.Drawing.Point(270, 79);
            this.checkBox5.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(65, 28);
            this.checkBox5.TabIndex = 53;
            this.checkBox5.Tag = "3";
            this.checkBox5.Text = "ws4";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Font = new System.Drawing.Font("新細明體", 18F);
            this.checkBox6.Location = new System.Drawing.Point(188, 79);
            this.checkBox6.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(65, 28);
            this.checkBox6.TabIndex = 52;
            this.checkBox6.Tag = "2";
            this.checkBox6.Text = "ws5";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Font = new System.Drawing.Font("新細明體", 18F);
            this.checkBox7.Location = new System.Drawing.Point(100, 79);
            this.checkBox7.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(65, 28);
            this.checkBox7.TabIndex = 51;
            this.checkBox7.Tag = "1";
            this.checkBox7.Text = "ws6";
            this.checkBox7.UseVisualStyleBackColor = true;
            this.checkBox7.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Font = new System.Drawing.Font("新細明體", 18F);
            this.checkBox8.Location = new System.Drawing.Point(18, 79);
            this.checkBox8.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(65, 28);
            this.checkBox8.TabIndex = 50;
            this.checkBox8.Tag = "0";
            this.checkBox8.Text = "ws7";
            this.checkBox8.UseVisualStyleBackColor = true;
            this.checkBox8.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // shapeContainer2
            // 
            this.shapeContainer2.Location = new System.Drawing.Point(3, 18);
            this.shapeContainer2.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            this.shapeContainer2.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.ovalShape9,
            this.ovalShape10,
            this.ovalShape11,
            this.ovalShape12,
            this.ovalShape13,
            this.ovalShape14,
            this.ovalShape15,
            this.ovalShape16});
            this.shapeContainer2.Size = new System.Drawing.Size(671, 169);
            this.shapeContainer2.TabIndex = 60;
            this.shapeContainer2.TabStop = false;
            // 
            // ovalShape9
            // 
            this.ovalShape9.Location = new System.Drawing.Point(596, 6);
            this.ovalShape9.Name = "ovalShape8";
            this.ovalShape9.Size = new System.Drawing.Size(50, 50);
            this.ovalShape9.Tag = "checkBox1";
            this.ovalShape9.Click += new System.EventHandler(this.ovalShape_Click);
            // 
            // ovalShape10
            // 
            this.ovalShape10.Location = new System.Drawing.Point(514, 6);
            this.ovalShape10.Name = "ovalShape7";
            this.ovalShape10.Size = new System.Drawing.Size(50, 50);
            this.ovalShape10.Tag = "checkBox2";
            this.ovalShape10.Click += new System.EventHandler(this.ovalShape_Click);
            // 
            // ovalShape11
            // 
            this.ovalShape11.Location = new System.Drawing.Point(432, 6);
            this.ovalShape11.Name = "ovalShape6";
            this.ovalShape11.Size = new System.Drawing.Size(50, 50);
            this.ovalShape11.Tag = "checkBox3";
            this.ovalShape11.Click += new System.EventHandler(this.ovalShape_Click);
            // 
            // ovalShape12
            // 
            this.ovalShape12.Location = new System.Drawing.Point(350, 6);
            this.ovalShape12.Name = "ovalShape5";
            this.ovalShape12.Size = new System.Drawing.Size(50, 50);
            this.ovalShape12.Tag = "checkBox4";
            this.ovalShape12.Click += new System.EventHandler(this.ovalShape_Click);
            // 
            // ovalShape13
            // 
            this.ovalShape13.Location = new System.Drawing.Point(268, 6);
            this.ovalShape13.Name = "ovalShape4";
            this.ovalShape13.Size = new System.Drawing.Size(50, 50);
            this.ovalShape13.Tag = "checkBox5";
            this.ovalShape13.Click += new System.EventHandler(this.ovalShape_Click);
            // 
            // ovalShape14
            // 
            this.ovalShape14.Location = new System.Drawing.Point(186, 6);
            this.ovalShape14.Name = "ovalShape3";
            this.ovalShape14.Size = new System.Drawing.Size(50, 50);
            this.ovalShape14.Tag = "checkBox6";
            this.ovalShape14.Click += new System.EventHandler(this.ovalShape_Click);
            // 
            // ovalShape15
            // 
            this.ovalShape15.Location = new System.Drawing.Point(104, 6);
            this.ovalShape15.Name = "ovalShape2";
            this.ovalShape15.Size = new System.Drawing.Size(50, 50);
            this.ovalShape15.Tag = "checkBox7";
            this.ovalShape15.Click += new System.EventHandler(this.ovalShape_Click);
            // 
            // ovalShape16
            // 
            this.ovalShape16.Location = new System.Drawing.Point(22, 6);
            this.ovalShape16.Name = "ovalShape1";
            this.ovalShape16.Size = new System.Drawing.Size(50, 50);
            this.ovalShape16.Tag = "checkBox8";
            this.ovalShape16.Click += new System.EventHandler(this.ovalShape_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(271, 140);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(114, 24);
            this.comboBox2.TabIndex = 62;
            this.comboBox2.Text = "red   0";
            this.comboBox2.Click += new System.EventHandler(this.comboBox2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 276);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBox1);
            this.Name = "Form1";
            this.Text = "109學年度 工業類科學生技藝競賽 電腦修護職種 第二站 崗位號碼:14";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer2;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape9;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape10;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape11;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape12;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape13;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape14;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape15;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape16;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ComboBox comboBox2;
    }
}

